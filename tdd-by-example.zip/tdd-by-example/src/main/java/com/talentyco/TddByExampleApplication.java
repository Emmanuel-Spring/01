package com.talentyco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TddByExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TddByExampleApplication.class, args);
	}

}
